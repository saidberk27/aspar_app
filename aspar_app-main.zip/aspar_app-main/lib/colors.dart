import 'package:flutter/material.dart';

class Renk {
  static Color koyuMavi = const Color(0xFF166FC0);
  static Color acikMavi = const Color(0xFF0FA9EA);
}
